package projeto.homologacao;

import javafx.application.Application;
import javafx.stage.Stage;

public class ItemDeCompraBoundary extends Application {

	@Override
	public void start(Stage stage) throws Exception {
		
	}

}
