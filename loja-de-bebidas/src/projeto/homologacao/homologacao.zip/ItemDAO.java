package projeto.homologacao;

import java.util.List;

public interface ItemDAO {

	void adicionar(Item i);
	List<Item> pesquisarPorNome(String nome);
	void remover(long id);
	void alterar(Item i);
}
