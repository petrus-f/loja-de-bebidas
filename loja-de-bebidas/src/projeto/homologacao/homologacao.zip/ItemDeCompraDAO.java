package projeto.homologacao;

import java.util.List;

public interface ItemDeCompraDAO {
	
	void adicionar(ItemDeCompra i);
	List<ItemDeCompra> pesquisarPorID(long id_compra, long id_item);
	void remover(long id);
	void alterar(ItemDeCompra i);
	
}
