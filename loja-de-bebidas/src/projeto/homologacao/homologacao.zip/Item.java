package projeto.homologacao;

import java.util.ArrayList;
import java.util.List;

public class Item {
	private long id;
	private String nome;
	private double valor_unitario;
	private boolean Plastico;
	private static List<Item> itens = new ArrayList<Item>();
	
	public Item(long id,String nome, double valor_unitario, boolean plastico) {
		this.id = id;
		this.nome = nome;
		this.valor_unitario = valor_unitario;
		Plastico = plastico;
		itens.add(this);
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getValor_unitario() {
		return valor_unitario;
	}
	public void setValor_unitario(double valor_unitario) {
		this.valor_unitario = valor_unitario;
	}
	public boolean isPlastico() {
		return Plastico;
	}
	public void setPlastico(boolean Plastico) {
		this.Plastico = Plastico;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
}
