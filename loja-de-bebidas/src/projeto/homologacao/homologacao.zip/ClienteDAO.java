package projeto.homologacao;

import java.util.List;

public interface ClienteDAO {
	
	void adicionar(Cliente c);
	List<Cliente> pesquisarPorNome(String nome);
	void remover(long id);
	void alterar(Cliente c);
}
